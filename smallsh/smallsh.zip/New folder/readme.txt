Instructions on compiling my program:
type in the following command:
gcc smallsh.c -o smallsh
Ignore all of the warnings. They do not cause any problems with the program.
This will create an executable called smallsh.
You can name the executable whatever you want to, 
but make sure you remember the name when executing it.
then run the grading script on it like this:
./p3testscript 2>&1. The output should be in a file called 1.